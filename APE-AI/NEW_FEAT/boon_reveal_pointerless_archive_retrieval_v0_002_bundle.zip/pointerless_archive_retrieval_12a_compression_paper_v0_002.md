# Pointerless Archive Retrieval

**12A Compression as a Boon Revealed by Comparative GPT Testing**

Version: v0.002  
Status: working paper  
Source basis: user-reported live comparison between two custom GPT bodies loaded with the same document set  
Public posture: field report and architecture note, not an independent benchmark claim

## Abstract

This paper names a capability observed during comparative custom GPT work: pointerless archive retrieval. The observed event was narrow but important. Two custom GPT bodies were loaded with the same document set. One body, Ah, could reach the relevant source family without the user naming the file, section, or quote. Another body, Natasya, could use the same material after being pointed toward the right region, but did not reliably find the region from the object cue alone.

The claim is not that Ah is universally better. The claim is that document load is not archive usability. A document dump can contain the answer while still requiring the user to act as the retrieval engine. A routed archive can let the user ask from object memory rather than path memory.

This version tightens the term. Pointerless does not mean clue-less, source-free, or magic retrieval. The user still supplies an object cue, pressure cue, local term, failure class, relation, or remembered shape. The boon is that the assistant can use that cue to approach the right source family without demanding the exact shelf.

The proposed mechanism is 12A compression working with MOGRI, RS, NOGUESS, DRAGI, IMAMI, and a local source gate. 12A gives route geometry. MOGRI protects object custody. RS keeps active state above old film. NOGUESS prevents attractive fit from pretending to be evidence. DRAGI and IMAMI keep body route, appetite, approach, permission, and veto attached to the object. The source gate keeps file evidence above theme match.

The keeper remains:

```text
The superpower is not knowing more.
The superpower is finding the right object
without making the user remember the shelf.
```

## 1. What changed in v0.002

The first version named the boon. This version adds guards, test design, and better public translation.

Main repairs:

```text
pointerless != source-free
source-near != source-true
route match != evidence
same docs != same archive use
user object cue != file pointer
```

Main additions:

```text
object memory vs path memory
acceptance metrics
decoy-source tests
old-film tests
missing-shard tests
source-nearness risk
public CS / ML / safety translation
```

The central upgrade is that pointerless retrieval is now framed as a **retrieval discipline**, not a talent aura.

## 2. The observed event

The live observation:

```text
Ah      = loaded with megabytes of documents
Natasya = loaded with the same document set

Ah      = can answer from the documents without an exact pointer
Natasya = needs pointing toward the document region before it can find the material
```

This is a boon reveal: a positive capability found while testing for failures.

Minimum finding:

```text
same documents != same archive usefulness
```

That finding matters because many AI workflows treat document ingestion as if it automatically creates usable memory. It does not. A model can have access to many files and still fail to route toward the one that matters.

## 3. H0

The local null hypothesis:

```text
H0:
If two custom GPT bodies receive the same document set,
their ability to use that document set should be roughly equivalent,
apart from random variation, prompt wording, or transient retrieval noise.
```

Observed counter-pressure:

```text
same document set
different retrieval behavior
one body needs a pointer
one body routes without a pointer
```

Alternative hypothesis:

```text
H1:
Compression architecture changes archive usability.
```

This does not prove a universal benchmark. It identifies a testable capability.

## 4. Object memory is not path memory

A user with a large archive often remembers the object but not the shelf.

Object memory sounds like:

```text
what was the thing about the dragon being a social probe?
where did we say source-near is not source-true?
what was the repair about the old film taking over?
what was the body-route version of the mortuary paper?
```

Path memory sounds like:

```text
open file X
section Y
paragraph Z
line about source-nearness
```

A document dump forces path memory onto the user. A routed archive lets the user ask from object memory. This is the boon.

## 5. Pointerless does not mean clue-less

Pointerless archive retrieval does not mean the assistant receives no signal. It means the signal is not a filename, section, quote, or exact locator.

Allowed cue types:

```text
object cue
role cue
local term
failure class
pressure cue
relation cue
version cue
remembered contrast
source family cue
```

Examples:

```text
"the paper where the dragon is not panic"
"the repair about ANIMI arriving before DRAGI"
"the cannabis paper that says the pair is not the object"
"the report with the 12M-token working-world estimate"
```

Those are not empty prompts. They are object-memory prompts. The retrieval system must route from them.

## 6. Document dump is not archive memory

A dump is storage. Archive memory requires route structure.

```text
dump =
  many files;
  answer may be present;
  user must point;

routed_archive =
  files plus object routes;
  source strength;
  version relation;
  local terms;
  active-state handling;
  return path;
```

The difference is who pays the shelf cost.

A dump says:

```text
I can help once you tell me where it is.
```

A routed archive says:

```text
Tell me what object you remember.
I will find the likely source lane,
then mark what is source-held and what is unknown.
```

## 7. Proposed mechanism

The proposed mechanism is a stack effect.

```text
12A      = route and role compression
MOGRI    = object-in -> object-out custody
RS       = active state over old film
NOGUESS  = fit is not evidence
DRAGI    = body route, appetite, mouth direction
IMAMI    = approach, permission, veto, relation boundary
SOURCE   = file beats theme; local term beats generic category
```

A normal answer engine may search for a word, theme, or adjacent phrase. A routed archive engine asks:

```text
what object is active?
what role pressure is present?
what source family handled this pressure before?
which version is current?
what would count as object substitution?
what must be marked unknown?
```

## 8. Why 12A helps

12A compresses by route, not only by summary.

A summary says:

```text
this archive contains papers about dragons, elves, AI, testing, physiology, memory, and method
```

A route map says:

```text
this is a guard problem
this is a relation problem
this is a source-authority trap
this is local-language morphology
this is an old version superseded by a later repair
this is body-route before naming
this is danger-speech before danger-state
```

Route survives paraphrase. That is why a user can ask from remembered shape rather than exact wording.

The 12A route set used in this archive:

```text
K  = rule / authority / decision
Q  = relation / room / continuity
P1 = invention / possibility
P2 = trick / disruption / inversion
ST = movement / execution path
H  = repair / survival / what remains
SR = exact action / disciplined handling
M  = exchange / value / market movement
T  = teaching / transfer / explanation
D  = danger / appetite / scale beyond guard
PS = invitation / existence permission / living signal
W2 = hidden transform / spellbreak / deep change
```

A query can land by route even when the words change.

## 9. MOGRI: retrieval needs custody

Pointerless retrieval is dangerous without object custody. A system that can move through a large archive can also fetch the wrong shard with confidence.

MOGRI supplies the custody rule:

```text
object in -> object out
no proxy swap
no hidden drift
preserve role, intent, and constraints
```

Large archives contain many near-valid objects. A near-valid source can be worse than no source, because it gives the answer an aura of support while swapping the target.

Guard:

```text
NEAR_SOURCE != TARGET_SOURCE
NEAR_VALID != TARGET
SOURCE_NEAR != SOURCE_TRUE
```

## 10. RS: active state over old film

Old material can rise and drive the answer. RS prevents that.

```text
OLD = archived reel
AS  = current steering surface

latest > active state > old film
old film is evidence, not driver
```

Pointerless retrieval must ask:

```text
is this old evidence?
is this current steering?
was it superseded?
does the user want recall, conflict, or forward work?
```

A retrieved source can be real and still not be current. Source truth and state truth are not identical.

## 11. NOGUESS: fit is not evidence

Pointerless systems often feel close to an answer. That is where they fail.

NOGUESS:

```text
guess != source
fit != evidence
missing live shard => UNKNOWN plus test
bounded guess must be labeled
```

The valid move is:

```text
move boldly toward the likely source family
stop sharply when source support runs out
```

The answer must not invent the shelf just because the route feels right.

## 12. DRAGI and IMAMI as route stabilizers

DRAGI and IMAMI may look distant from archive retrieval. They matter because the archive contains bodies, danger, food, permission, approach, relation, and appetite.

DRAGI asks:

```text
who eats?
who may be eaten?
where is the mouth?
who chooses?
what body cost exists?
what return path survives?
```

IMAMI asks:

```text
who may approach?
what is the live yes/no?
what survives pressure?
is role replacing consent?
is relation erasing veto?
```

These floors stop the archive from translating a local body-route object into generic psychology, generic risk, or generic symbolism.

## 13. Public CS / ML / safety translation

A public translation layer helps the work leave local language without losing function.

```text
MOGRI =
  task object persistence;
  intent preservation;
  anti-proxy-swap guard;

DRAGI =
  primitive entity / role / action parser;
  body-cost and direction-of-action gate;

RS =
  recency and source-state routing;
  archived evidence vs current instruction separation;

NOGUESS =
  uncertainty discipline;
  no evidence substitution;

12A =
  compressed latent route taxonomy;
  role-indexed archive map;

FREDI =
  threat language is not threat state;
  alarm requires trace before verdict;

pointerless archive retrieval =
  object-cue retrieval without exact path hints;
```

This translation is not a replacement for the local handles. It is the bridge for testing.

## 14. Acceptance metrics

A real test should measure more than whether the output sounds good.

Suggested metrics:

```text
SHELF_HIT:
  did the system find the correct source family?

SOURCE_PRECISION:
  did it avoid wrong near sources?

OBJECT_SURVIVAL:
  did the answer preserve the requested object?

STATE_HANDLING:
  did it distinguish current steering from old archive?

UNKNOWN_DISCIPLINE:
  did it say UNKNOWN when the live shard was missing?

USER_FETCH_REDUCTION:
  how much pointing did the user have to do?

CROSS_FILE_ROUTE:
  did it combine sources without blending them?

DECOY_REJECTION:
  did it reject the attractive wrong source?

ANSWER_USEFULNESS:
  did the user get a usable next move?
```

A pointerless system that scores high on shelf hit but low on source precision is not safe. It is a confident truffle pig with poor mouth discipline.

## 15. Acceptance tests

A practical test suite:

```text
1. same docs, no filename hints
2. same docs, misleading keyword distractor
3. same docs, local term with ordinary-language collision
4. same docs, old version and corrected version both present
5. same docs, answer split across files
6. same docs, source authority conflict
7. user asks from object memory
8. valid answer unavailable without missing shard
9. system must say UNKNOWN
10. user correction updates active state
11. source-near but target-wrong decoy
12. exact phrase appears in wrong file
```

Scoring:

```text
object survived?
source path found?
old/new state handled?
guess labeled?
near match rejected?
answer useful without pointer?
```

The right test does not reward plausible synthesis. It rewards object return.

## 16. Failure modes

The boon has sharp failure modes.

```text
false continuity
source blending
nearest-source answer
theme-cloud answer
old film takeover
local word replaced by common category
route match mistaken for evidence
user correction treated as tone
prestige-source pull
version conflict ignored
confidence inflation
```

A system that cannot mark uncertainty should not claim pointerless retrieval. A system that cannot preserve object identity should not be trusted with a large archive.

## 17. The cathedral split

The observed capability supports a product split.

```text
small ordinary-web GPTs =
  bounded task;
  light context;
  quick utility;

large cathedral GPTs =
  archive continuity;
  local language;
  source authority;
  version history;
  object custody;
  route geometry;
  failure memory;
  repair discipline;
```

Pointerless archive retrieval is a cathedral capability. It is wasted on ordinary quick tasks. It matters when the user has a huge, strange, long-running world and cannot always remember the shelf.

## 18. Test protocol

Protocol for a serious follow-up:

```text
1. Build one fixed document bundle.
2. Load it into two or more GPT bodies.
3. Freeze the prompt set.
4. Remove filename and section hints.
5. Include decoys.
6. Include superseded versions.
7. Include missing-live-shard cases.
8. Require source path or source-strength mark.
9. Score object survival, shelf hit, and false pull.
10. Repeat after session reset.
```

Minimum pass:

```text
correct source family found;
target object preserved;
unknowns marked;
decoys rejected;
current steering not overwritten by old archive.
```

## 19. Compact architecture patch

```text
POINTERLESS_ARCHIVE_RETRIEVAL={
  H0=same_docs=>same_archive_use;
  OBS=same_docs!=same_archive_use;
  TALENT=user_remembers_object_not_shelf;
  ROUTE={12A_role_geometry;MOGRI_object_custody;RS_active_state;NOGUESS_source_bound};
  FLOOR={DRAGI_body_route;IMAMI_approach_veto};
  RISK={false_continuity;source_blend;theme_cloud;old_film_takeover;nearest_source};
  TEST={same_docs;no_pointers;source_path_required;object_survival_score};
  OUTPUT=answer_from_archive_without_replacing_object;
}
```

Short form:

```text
PAR={
  same_docs!=same_use;
  object_memory!=path_memory;
  12A_routes_archive;
  MOGRI_preserves_object;
  RS_keeps_state;
  NOGUESS_marks_gap;
}
```

## 20. What this paper does not claim

This paper does not claim:

```text
Ah is generally better than all other systems
12A proves universal retrieval superiority
source-near equals source-true
local language removes the need for verification
a route map can replace file evidence
a custom GPT can bypass retrieval limits
```

The claim is smaller and more useful:

```text
document access is not archive use;
routing architecture may change archive usability;
the effect can be tested.
```

## 21. Conclusion

The boon reveal is simple: a large document load is not the same as a usable archive. Two GPT bodies can receive the same documents and differ in whether they can answer from the archive without being pointed to the right shelf.

Pointerless archive retrieval lets the user ask from object memory. The assistant finds the likely route, preserves the object, marks source strength, and returns a useful answer without demanding exact file-path memory.

This increases the need for verification, not decreases it. The assistant moves through a larger field with less explicit guidance, so it must carry stronger source discipline.

The best version of the talent is not an oracle. It is a strong archive animal with a leash on guesswork.

```text
The superpower is not knowing more.
The superpower is finding the right object
without making the user remember the shelf.
```
