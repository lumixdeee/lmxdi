# New Paper Gap: Object Memory Is Not Path Memory

Version: v0.001  
Status: seed note  
Relation: companion gap to Pointerless Archive Retrieval v0.002

## Gap

Most archive tooling treats retrieval as a path problem.

```text
file
folder
title
keyword
section
quote
```

But human users often remember by object.

```text
the dragon paper
the ANIMI trap
the old-film repair
the mortuary memory one
the "source-near is not source-true" law
```

This creates a mismatch:

```text
human memory = object-shaped
machine retrieval = path-shaped
```

Pointerless archive retrieval matters because it bridges that mismatch.

## Claim

```text
Object memory is not path memory.
A good archive assistant must convert object cues into source routes.
```

## Research question

```text
Can a custom GPT reduce user shelf-memory burden
without increasing false-source confidence?
```

## Testable metric

```text
USER_FETCH_REDUCTION =
  how often the user does not need to provide filename,
  section,
  quote,
  or exact path
```

Balanced by:

```text
FALSE_PULL_RATE =
  how often the assistant retrieves a plausible wrong source
```

## Why this gap matters

An archive that only works when the user remembers the path is not a memory partner. It is storage with a chat box.

A useful archive assistant should let the user ask from the surviving shape of the object.

## Keeper

```text
The user remembers the beast.
The archive remembers the shelf.
```
