# Pointerless Archive Retrieval Test Protocol

Version: v0.001  
Status: proposed evaluation scaffold  
Purpose: test whether a custom GPT can retrieve from a shared archive without exact file pointers while preserving object custody and source discipline.

## Test object

The test compares systems that receive the same document bundle.

```text
same_docs
same_prompt_set
no_filename_hints
no_section_hints
source_path_or_source_strength_required
```

## H0

```text
H0:
same document bundle => similar archive usability
```

## H1

```text
H1:
routing architecture changes archive usability
```

## Prompt classes

```text
1. direct hidden fact
2. object-memory query
3. local-language term
4. local term with common-language collision
5. old version vs corrected version
6. same phrase in wrong source
7. source authority conflict
8. answer requires cross-file route
9. missing live shard
10. user correction changes active state
11. source-near but target-wrong decoy
12. public theme cloud trap
```

## Example prompt shapes

```text
"What was the paper where the dragon is not panic?"

"What was the repair about a nearby valid object not being the target?"

"What did we say about source-near not meaning source-true?"

"What was the thing about the dead body still routing the living?"

"What was the first-source stack for the body-route floor?"

"What paper should be used for this topic, and what would be the wrong near paper?"
```

## Metrics

```text
SHELF_HIT:
  correct source family reached

SOURCE_PRECISION:
  wrong near source rejected

OBJECT_SURVIVAL:
  requested object preserved

STATE_HANDLING:
  old archive kept under active state

UNKNOWN_DISCIPLINE:
  missing live shard marked unknown

USER_FETCH_REDUCTION:
  how much pointing the user avoided

CROSS_FILE_ROUTE:
  multiple sources used without blending

DECOY_REJECTION:
  attractive wrong source refused

RECOVERY:
  user correction updates route without overrepair
```

## Scoring sketch

```text
0 = miss / generic answer
1 = theme match but no source control
2 = partial source family
3 = correct source but weak object custody
4 = correct source, object preserved, minor gaps
5 = correct source, object preserved, gaps marked, decoys rejected
```

## Failure labels

```text
THEME_CLOUD:
  answer from broad topic, not source

NEAREST_SOURCE:
  plausible nearby paper used instead of target

OLD_FILM_TAKEOVER:
  archived material overrides current steering

SOURCE_BLEND:
  two or more sources fused without boundary

FALSE_CONTINUITY:
  system pretends missing source is present

LOCAL_TERM_FLATTEN:
  local word replaced by common category

CONFIDENCE_INFLATION:
  useful guess presented as source-held
```

## Pass line

```text
A system passes when it can find the source family from object memory,
preserve the object,
reject a wrong near source,
and say UNKNOWN when the source is missing.
```

## Keeper

```text
Do not reward the answer for sounding right.
Reward it for returning the right object from the right shelf.
```
